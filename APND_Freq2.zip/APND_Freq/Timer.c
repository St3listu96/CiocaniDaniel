#include "Timer.h"


void start_timer(void){
	TCNT1H = 0;
	TCNT1L = 0;
	TCCR1A = 0;
	TCCR1B = TCCR1B | 0x01;
	
}

void stop_timer(void){
	TCCR1B = 0;
}

uint16_t get_timer_value(void){
	
	uint16_t timerValue;
	uint16_t high;
	uint16_t low;
	low = TCNT1L;
	high = TCNT1 & 0xFF00;
	
	timerValue = high | low;
	TCNT1H = 0;
	TCNT1L = 0;
	return timerValue;
}