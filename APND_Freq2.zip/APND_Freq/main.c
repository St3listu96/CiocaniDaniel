#define F_CPU 14745600UL

#include <avr/io.h>
#include <stdio.h>
#include <util/delay.h>
#include "uart.h"
#include "adc.h"
#include "Timer.h"

#define BUFFER_SIZE 300
#define VT_LO 110
#define VT_HI 140
#define POSITIVE 1


int main(void)
{
	int i=0;
	init();
	initADC();
	uint8_t buffer1[BUFFER_SIZE];
	uint8_t buffer2[BUFFER_SIZE];
	uint8_t channel1=1;
	uint8_t channel2=2;
	uint8_t value;
	uint16_t timerValue;
	uint8_t state;
	
	while(1){
		i=0;
		
		if(POSITIVE == 1){
			value = startADC(channel1);
			while(value < VT_HI){
				value = startADC(channel1);
			}
			
			value = startADC(channel1);
			while(value > VT_LO){
				value = startADC(channel1);
			}
			state = 0;
			start_timer();
			while(i < BUFFER_SIZE){
						buffer1[i] = startADC(channel1);
						buffer2[i] = startADC(channel2);
						
				switch(state){

				case 0:
			
				if(buffer1[i] <= VT_LO){
					state = 1;
				}
				break;
				
				case 1:
				if((buffer1[i] >= VT_HI)){
					state = 2;
				}
				break;
				
				case 2:
				stop_timer();
				timerValue = get_timer_value();
				state =3;
				break;
				}
			i++;
			}
		}
		else{
			value = startADC(channel1);
			while(value > VT_LO){
				value = startADC(channel1);
			}
			
			value = startADC(channel1);
			while(value < VT_HI){
				value = startADC(channel1);
			}
		}
		//timerValue = (timerValue * 1000) / (F_CPU*1000);
		osciloscope(buffer1,buffer2,BUFFER_SIZE,timerValue);
	}
}