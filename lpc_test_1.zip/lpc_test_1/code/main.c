#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "at.h"
#include "LPC177x_8x.h"
#include "system_LPC177x_8x.h"
#include <retarget.h>

#include <DRV\drv_sdram.h>
#include <DRV\drv_lcd.h>
#include <DRV\drv_uart.h>
#include <DRV\drv_touchscreen.h>
#include <DRV\drv_led.h>
#include <utils\timer_software.h>
#include <utils\timer_software_init.h>


char at_command_csq[] = "AT+CSQ\r\n";
char at_command[] = "AT\r\n";
timer_software_handler_t handler;

void timer_callback_1(timer_software_handler_t h)
{
	
}

void SendCommand(unsigned char *command){
		DRV_UART_FlushRX(UART_3);
		DRV_UART_FlushTX(UART_3);
		DRV_UART_Write(UART_3, command, strlen(command));
}

void GetCommandResponse()
{
	  uint8_t ch;
	  BOOLEAN ready = FALSE;
		timer_software_handler_t handler;
	  TIMER_SOFTWARE_reset_timer(handler);
	  TIMER_SOFTWARE_start_timer(handler);
	  while ((!TIMER_SOFTWARE_interrupt_pending(handler)) && (ready == FALSE)){
			
			while (DRV_UART_BytesAvailable(UART_3) > 0){
					DRV_UART_ReadByte(UART_3, &ch);
					if (at_parse(ch) == STATUS_OK){
						ready = TRUE;
					}
				
			}	 
	  }
} 

void ExecuteCommand(){
			SendCommand(at_command_csq);
			GetCommandResponse();
}

uint32_t To_dBmW(uint32_t asu){
		return 2*asu-113;
}


void testLCD()
{
	uint32_t i,j;
	LCD_PIXEL foreground = {0, 255, 0, 0};
	LCD_PIXEL background = {0, 0, 0, 0};
	
	
	for (i = 0; i < LCD_HEIGHT; i++)
	{
		for (j = 0; j < LCD_WIDTH / 3; j++)
		{
			DRV_LCD_PutPixel(i, j, 255, 0, 0);
		}
		for (j = LCD_WIDTH / 3; j < 2 * (LCD_WIDTH / 3); j++)
		{
			DRV_LCD_PutPixel(i, j, 230, 220, 0);
		}
		for (j = 2 * (LCD_WIDTH / 3); j < LCD_WIDTH; j++)
		{
			DRV_LCD_PutPixel(i, j, 0, 0, 255);
		}
	}

	DRV_LCD_Puts("Hello", 20, 30, foreground, background, TRUE);
	DRV_LCD_Puts("Hello", 20, 60, foreground, background, FALSE);	
}

void TouchScreenCallBack(TouchResult* touchData)
{
	printf("touched X=%3d Y=%3d\n", touchData->X, touchData->Y);		
	
}

void BoardInit()
{
	
	TIMER_SOFTWARE_init_system();
	
	
	DRV_SDRAM_Init();
	
	initRetargetDebugSystem();
	DRV_LCD_Init();
	DRV_LCD_ClrScr();
	DRV_LCD_PowerOn();	
	
	DRV_TOUCHSCREEN_Init();
	DRV_TOUCHSCREEN_SetTouchCallback(TouchScreenCallBack);
	DRV_LED_Init();
	printf ("Hello\n");	
	
	handler = TIMER_SOFTWARE_request_timer();
	TIMER_SOFTWARE_configure_timer(handler, MODE_1, 100, 1);
	TIMER_SOFTWARE_set_callback(handler, timer_callback_1);
	TIMER_SOFTWARE_start_timer(handler);
}

int main(void)
{
	uint8_t ch;
	uint32_t asu;
	uint32_t dbmw;
	
	char at_command[] = "AT\n\r";
	
	BoardInit();
	testLCD();
	
	DRV_UART_Configure(UART_3, UART_CHARACTER_LENGTH_8, 115200, UART_PARITY_NO_PARITY, 1, TRUE, 3);
	DRV_UART_Configure(UART_2, UART_CHARACTER_LENGTH_8, 115200, UART_PARITY_NO_PARITY, 1, TRUE, 3);
	
	SendCommand(at_command);
	TIMER_SOFTWARE_Wait(1000);
	
	SendCommand(at_command);
	TIMER_SOFTWARE_Wait(1000);
	
	SendCommand(at_command);
	TIMER_SOFTWARE_Wait(1000);
	
	while (1){
		if (TIMER_SOFTWARE_interrupt_pending(handler)){
				ExecuteCommand(at_command_csq);
				if (CommandResponseValid()){
						asu = ExtractData(at.data[0]);
						dbmw = ToDbmw(asu);
						printf("%d",dbmw);
				}
			TIMER_SOFTWARE_clear_interrupt(handler);
		}
 } 
	
	/*while(1)
	{
		DRV_LED_Toggle(LED_4);
		
	}*/
	
	/*
	while(1)
	{
		DRV_UART_SendByte(UART_3, 'A');
	//	TIMER_SOFTWARE_Wait(1000);
	}
	*/
	/*
	while(1)
	{
		if (DRV_UART_ReadByte(UART_3, &ch) == OK)
		{
			DRV_UART_SendByte(UART_3, ch);
		}		
	}
*/
	while(1)
	{
		if (DRV_UART_ReadByte(UART_0, &ch) == OK)
		{
			DRV_UART_SendByte(UART_3, ch);
		}
		if (DRV_UART_ReadByte(UART_3, &ch) == OK)
		{
			DRV_UART_SendByte(UART_0, ch);
		}
		if (DRV_UART_ReadByte(UART_2, &ch) == OK)
		{
			DRV_UART_SendByte(UART_0, ch);
		}
	}
	
	while(1)
	{
		DRV_UART_Process();
		DRV_TOUCHSCREEN_Process();
	}
	
	return 0; 
}
