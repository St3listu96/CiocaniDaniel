var searchData=
[
  ['timer_5fsoftware_5fcallback',['TIMER_SOFTWARE_Callback',['../group___timer_software.html#ga6f2629dc43e34fafae17971375f6ce81',1,'timer_software.h']]],
  ['timer_5fsoftware_5fhandler_5ft',['timer_software_handler_t',['../group___timer_software.html#gafd3d357f97f78766a1b3f5653483b2ea',1,'timer_software.h']]]
];
