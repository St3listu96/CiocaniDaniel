#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define MAX_LINE 1000
#define STR_SIZE 50
#define true 1
#define false 0

typedef int bool;

typedef enum {
	STATUS_OK,
	STATUS_ERROR
}STATE_MACHINE;

typedef struct {
	char data[MAX_LINE][STR_SIZE];
	bool ok;
	int line;
	int flag;
}AT;

extern AT atdata;
STATE_MACHINE at_parse(char ch);