var searchData=
[
  ['max_5fnr_5ftimers',['MAX_NR_TIMERS',['../timer__software_8h.html#a37a3ada7ab507afd64385ce9df532a0e',1,'timer_software.h']]],
  ['mhz',['MHZ',['../drv__general_8h.html#a91dd8b26b5bbdd9ca65de2ebb0119743',1,'drv_general.h']]]
];
