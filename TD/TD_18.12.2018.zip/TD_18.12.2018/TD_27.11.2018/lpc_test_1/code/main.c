#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "at.h"
#include "LPC177x_8x.h"
#include "system_LPC177x_8x.h"
#include <retarget.h>

#include <DRV\drv_sdram.h>
#include <DRV\drv_lcd.h>
#include <DRV\drv_uart.h>
#include <DRV\drv_touchscreen.h>
#include <DRV\drv_led.h>
#include <utils\timer_software.h>
#include <utils\timer_software_init.h>


char at_command_csq[] = "AT+CSQ\r\n";
char at_command[] = "AT\r\n";
timer_software_handler_t handler;

void timer_callback_1(timer_software_handler_t h)
{
	
}

void SendCommand(char *command){
		DRV_UART_FlushRX(UART_3);
		DRV_UART_FlushTX(UART_3);
		DRV_UART_Write(UART_3, command, strlen(command));
}
timer_software_handler_t new_handler;
void GetCommandResponse()
{
	  uint8_t ch;
	  //BOOLEAN ready = FALSE;
		uint8_t ready = 0;
		
	  //TIMER_SOFTWARE_reset_timer(new_handler);
		atdata.ok = false;
		TIMER_SOFTWARE_configure_timer(new_handler, MODE_1, 30000, true);
	  TIMER_SOFTWARE_start_timer(new_handler);
		while ((!TIMER_SOFTWARE_interrupt_pending(new_handler)) && (ready == 0)){
			
			while (DRV_UART_BytesAvailable(UART_3) > 0){
					DRV_UART_ReadByte(UART_3, &ch);
					//printf("%c",ch);
					if (((at_parse(ch) == STATUS_OK) && (atdata.ok == true))){
						ready = 1;
					}
			}	 
	  }
} 

void ExecuteCommand(){
			SendCommand(at_command_csq);
			//printf("Comanda trimisa.\n");
			GetCommandResponse();
}

uint32_t ExtractData(char *text){
		int i;
		uint32_t csq=0;
		for(i=0;i<strlen(text);i++){
				if(text[i]==',')
					break;
				if(text[i]>='0' && text[i]<='9')
					csq = csq*10 + text[i] - '0';
		}
		return csq;
}

uint32_t To_dBmW(uint32_t asu){
		return 2*asu-113;
}


void testLCD()
{
	uint32_t i,j;
	LCD_PIXEL foreground = {0, 255, 0, 0};
	LCD_PIXEL background = {0, 0, 0, 0};
	
	
	/*for (i = 0; i < LCD_HEIGHT; i++)
	{
		for (j = 0; j < LCD_WIDTH / 3; j++)
		{
			DRV_LCD_PutPixel(i, j, 255, 0, 0);
		}
		for (j = LCD_WIDTH / 3; j < 2 * (LCD_WIDTH / 3); j++)
		{
			DRV_LCD_PutPixel(i, j, 230, 220, 0);
		}
		for (j = 2 * (LCD_WIDTH / 3); j < LCD_WIDTH; j++)
		{
			DRV_LCD_PutPixel(i, j, 0, 0, 255);
		}
	}*/
	
	for (i=LCD_HEIGHT	; i>=222 ; i--){
		for (j=1 ; j<= 101; j++){
				DRV_LCD_PutPixel(i, j, 217, 217, 217);
		}
	}
	
	for (i=LCD_HEIGHT	; i>=222 ; i--){
		for (j=127 ; j<= 227; j++){
				DRV_LCD_PutPixel(i, j, 217, 217, 217);
		}
	}
	
	for (i=LCD_HEIGHT	; i>=222 ; i--){
		for (j=253 ; j<= 353; j++){
				DRV_LCD_PutPixel(i, j, 217, 217, 217);
		}
	}
	
	for (i=LCD_HEIGHT	; i>=222 ; i--){
		for (j=379 ; j<= 479; j++){
				DRV_LCD_PutPixel(i, j, 217, 217, 217);
		}
	}
	
	for (i=200; i>=20 ; i--){
		for (j=1 ; j<= 227; j++){
				DRV_LCD_PutPixel(i, j, 255, 255, 255);
		}
	}
	
	for (i=200	; i>=20 ; i--){
		for (j=253 ; j<= 479; j++){
				DRV_LCD_PutPixel(i, j, 255, 255, 255);
		}
	}

	DRV_LCD_Puts("<-", 51, 232 , foreground, background, TRUE);
	DRV_LCD_Puts("->", 177, 232 , foreground, background, TRUE);
	DRV_LCD_Puts("Send", 290, 232 , foreground, background, TRUE);
	DRV_LCD_Puts("Delete", 397, 232 , foreground, background, TRUE);
}

void TouchScreenCallBack(TouchResult* touchData)
{
	printf("touched X=%3d Y=%3d\n", touchData->X, touchData->Y);		
	
}

void BoardInit()
{
	
	TIMER_SOFTWARE_init_system();
	
	
	DRV_SDRAM_Init();
	
	initRetargetDebugSystem();
	DRV_LCD_Init();
	DRV_LCD_ClrScr();
	DRV_LCD_PowerOn();	
	
	DRV_TOUCHSCREEN_Init();
	DRV_TOUCHSCREEN_SetTouchCallback(TouchScreenCallBack);
	DRV_LED_Init();
		
	
	handler = TIMER_SOFTWARE_request_timer();
	TIMER_SOFTWARE_configure_timer(handler, MODE_1, 100, 1);
	TIMER_SOFTWARE_set_callback(handler, timer_callback_1);
	TIMER_SOFTWARE_start_timer(handler);
}

int main(void)
{
	uint8_t ch;
	uint32_t asu;
	uint32_t dbmw;
	uint32_t i,j;
	char text[25];
	uint8_t counter=0;
	uint32_t x;
	uint32_t y;
	TouchResult *coordonate;
	LCD_PIXEL foreground = {0, 255, 0, 0};
	LCD_PIXEL background = {0, 0, 0, 0};
	

	//char testCSQ[] = "CSQ: 21,0";
	
	BoardInit();
	testLCD();
	
	
	
	DRV_UART_Configure(UART_3, UART_CHARACTER_LENGTH_8, 115200, UART_PARITY_NO_PARITY, 1, TRUE, 3);
	DRV_UART_Configure(UART_2, UART_CHARACTER_LENGTH_8, 115200, UART_PARITY_NO_PARITY, 1, TRUE, 3);
	handler = TIMER_SOFTWARE_request_timer();
	TIMER_SOFTWARE_configure_timer(handler, MODE_1, 1000, true);
	TIMER_SOFTWARE_start_timer(handler);
	
	new_handler = TIMER_SOFTWARE_request_timer();
	
	SendCommand(at_command);
	TIMER_SOFTWARE_Wait(1000);
	
	
	SendCommand(at_command);
	TIMER_SOFTWARE_Wait(1000);
	
	
	SendCommand(at_command);
	TIMER_SOFTWARE_Wait(1000);
	
	while(1){
		printf("test\n");
		while(TouchGet(coordonate) == true){
				x = coordonate->X;
				printf("%d\n",x);
				y = coordonate->Y;
				printf("%d\n",y);
		}
			/*if(x!=0 && y!=0){
					printf("AM APASAT\n");
			}
				//if((x<=LCD_HEIGHT && x>=222) && (y>=1 && y<=101)){
					counter++;
			//printf("%d %d\n",x,y);
		*/
		}
		
		
	
	
	while (1){
		if (TIMER_SOFTWARE_interrupt_pending(handler)){
				sprintf(text,"Counter is %d",counter);
				DRV_LCD_Puts(text, 60, 165 , foreground, background, FALSE);
				counter++;
				ExecuteCommand();
				//printf("%s\n",atdata.data[0]);
				asu = ExtractData(atdata.data[0]);
				//printf("-%d-",asu);
				dbmw = To_dBmW(asu);
				printf("Power signal : %d\n",dbmw);
				sprintf(text,"Power signal : %d",dbmw);
				DRV_LCD_Puts(text, 10, 25 , foreground, background, FALSE);
			
				atdata.flag = 1;
				SendCommand("AT+GSN\r\n");
				GetCommandResponse();
				
				printf("Modem IMEI : %s\n",atdata.data[1]);
				sprintf(text,"IMEI : %s",atdata.data[1]);
				DRV_LCD_Puts(text, 10, 45 , foreground, background, FALSE);
				
				
				
				atdata.flag = 0;
				SendCommand("AT+CREG?\r\n");
				GetCommandResponse();
				asu = ExtractData(atdata.data[0]);
				if((asu == 0) || (asu == 2)){
					printf("State of registration : UNREGISTERED\n");
					sprintf(text,"Registration : UNREGISTERED");
					DRV_LCD_Puts(text, 10, 65 , foreground, background, FALSE);
				}
				else if(asu == 1){
					printf("State of registration : Home network\n");
					sprintf(text,"Registration : Home network");
					DRV_LCD_Puts(text, 10, 65 , foreground, background, FALSE);
				}
				else if(asu == 3){
					printf("State of registration : Registered denied\n");
					sprintf(text,"Registration : Registered denied");
					DRV_LCD_Puts(text, 10, 65 , foreground, background, FALSE);
				}
				else{
					printf("State of registration : Unknown\n");
					sprintf(text,"Registration : Unknown");
					DRV_LCD_Puts(text, 10, 65 , foreground, background, FALSE);
				}
				
			
				
				atdata.flag = 1;
				SendCommand("AT+GMI\r\n");
				GetCommandResponse();
				printf("Modem manufacturer : %s\n",atdata.data[1]);
				sprintf(text,"Manufacturer : %s",atdata.data[1]);
				DRV_LCD_Puts(text, 10, 85 , foreground, background, FALSE);
				
				
				atdata.flag = 1;
				SendCommand("AT+GMR\r\n");
				GetCommandResponse();
			
				printf("Modem software version: %s\n",atdata.data[2]);
				sprintf(text,"SW: %s",atdata.data[2]);
				DRV_LCD_Puts(text, 10, 105 , foreground, background, FALSE);
				
				atdata.flag = 0;
				SendCommand("AT+COPS?\r\n");
				GetCommandResponse();
				asu = ExtractData(atdata.data[0]);
				if (asu == 0){
					printf("Operator name: \n");
					sprintf(text,"Operator name: ");
					DRV_LCD_Puts(text, 10, 125 , foreground, background, FALSE);
				}
				else{
					printf("Operator name: \n");
					sprintf(text,"Operator name: ");
					DRV_LCD_Puts(text, 10, 125 , foreground, background, FALSE);
				}
				
				
				
				
			TIMER_SOFTWARE_clear_interrupt(handler);
		}
	//	DRV_TOUCHSCREEN_Process();
		while(TouchGet(coordonate) == true){
				x = coordonate->X;
				y = coordonate->Y;
				
		}
		//if((xAux != 0) && (yAux !=0)){
				if((x<=LCD_HEIGHT && x>=222) && (y>=1 && y<=101)){
					counter =0;
				}
			
		//}
		
		
 } 
	
	/*while(1)
	{
		DRV_LED_Toggle(LED_4);
		
	}*/
	
	/*
	while(1)
	{
		DRV_UART_SendByte(UART_3, 'A');
	//	TIMER_SOFTWARE_Wait(1000);
	}
	*/
	/*
	while(1)
	{
		if (DRV_UART_ReadByte(UART_3, &ch) == OK)
		{
			DRV_UART_SendByte(UART_3, ch);
		}		
	}
*/
	while(1)
	{
		if (DRV_UART_ReadByte(UART_0, &ch) == OK)
		{
			DRV_UART_SendByte(UART_3, ch);
		}
		if (DRV_UART_ReadByte(UART_3, &ch) == OK)
		{
			DRV_UART_SendByte(UART_0, ch);
		}
		if (DRV_UART_ReadByte(UART_2, &ch) == OK)
		{
			DRV_UART_SendByte(UART_0, ch);
		}
	}
	
	while(1)
	{
		DRV_UART_Process();
		DRV_TOUCHSCREEN_Process();
	}
	
	return 0; 
}
