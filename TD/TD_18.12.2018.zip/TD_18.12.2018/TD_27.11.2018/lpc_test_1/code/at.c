#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "at.h"
#define CR 13
#define LF 10

AT atdata;

STATE_MACHINE at_parse(char ch) {
	static uint32_t state = 0;
	static uint32_t line;
	static uint32_t chIndex;
	static uint32_t i;

	//printf("------%d-,-%c- \n", state,ch); //pentru debug

	switch (state) {
	case 0:
		if (ch == CR) {
			state = 1;
		}
		else {
			//printf("STATE : %d , Missing CR\n",state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;

	case 1:
		if (ch == LF) {
		
			if(atdata.flag == 1){
					state = 14;
			}
			else{
					state = 2;
			}
		}
		else {
			//printf("STATE : %d , Missing LF\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 2:
		if (ch == 'O') {
			state = 3;
		}
		else if (ch == 'E') {
			state = 7;
		}
		else if (ch == '+') {
			chIndex = 0;
			line = 0;
			state = 14;
		}
		else {
			//printf("STATE : %d , The next character need to be ('O','E','+')\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 3:
		if (ch == 'K') {
			state = 4;
		}
		else {
			//printf("STATE : %d , The next character need to be 'K'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 4:
		if (ch == CR) {
			state = 5;
		}
		else {
			//printf("STATE : %d , Missing CR\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 5:
		if (ch == LF) {
			atdata.ok = true;
			state = 0;
			return STATUS_OK;
		}
		else {
			//printf("STATE : %d , Missing LF\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 7:
		if (ch == 'R') {
			state = 8;
		}
		else {
			//printf("STATE : %d , The next character need to be 'R'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 8:
		if (ch == 'R') {
			state = 9;
		}
		else {
			//printf("STATE : %d , The next character need to be 'R'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 9:
		if (ch == 'O') {
			state = 10;
		}
		else {
			//printf("STATE : %d , The next character need to be 'O'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 10:
		if (ch == 'R') {
			state = 11;
		}
		else {
			//printf("STATE : %d , The next character need to be 'R'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 11:
		if (ch == CR) {
			state = 12;
		}
		else {
			//printf("STATE : %d , Missing CR\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 12:
		if (ch == LF) {
			//printf("Simple ERROR\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		else {
			//printf("STATE : %d , Missing LF\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 14:
		if (ch != CR) {
			atdata.data[line][chIndex] = ch;
			chIndex++;
			state = 14;
			return STATUS_OK;
		}
		else if (ch == CR) {
			state = 15;
			return STATUS_OK;
		}
		break;
	case 15:
		if (ch == LF) {
			atdata.data[line][chIndex] = '\0';
			line++;
			chIndex = 0;
			state = 16;
			return STATUS_OK;
		}
		else {
			//printf("STATE : %d , Missing LF\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 16:
		if (ch == CR) {
			state = 17;
		}
		else if (ch == '+') {
			state = 14;
		}
		else {
			//printf("STATE : %d , The next character need to be '<CR>' or '+'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 17:
		if (ch == LF) {
			state = 18;
		}
		else {
			//printf("STATE : %d , Missing LF\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 18:
		atdata.line = line;

		if (ch == 'O') {
			state = 19;
		}
		else if (ch == 'E') {
			state = 23;
		}
		else {
			//printf("STATE : %d , The next character need to be 'O' or 'E'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 19:
		if (ch == 'K') {
			state = 4;
		}
		else {
			//printf("STATE : %d , The next character need to be 'K'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	case 23:
		if (ch == 'R') {
			state = 8;
		}
		else {
			//printf("STATE : %d , The next character need to be 'R'\n", state);
			atdata.ok = false;
			return STATUS_ERROR;
		}
		break;
	}
}