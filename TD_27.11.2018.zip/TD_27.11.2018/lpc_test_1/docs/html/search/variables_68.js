var searchData=
[
  ['handle',['handle',['../struct_____f_i_l_e.html#ac65d6afc3b2c74e74d56195829a1626f',1,'__FILE']]]
];
